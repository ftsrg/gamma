Gamma Statechart Composition Framework
Version 2.10.0

The Gamma Statechart Composition Framework is a toolset to model, verify and generate code for component-based reactive systems. The framework builds on Yakindu, an open source statechart modeling tool and provides an additional modeling layer to instatiate a communicating network of statecharts. Compositionality is hierarchical, which facilitates the creation of reusable component libraries. Individual statecharts, as well as composite statechart networks can be validated and verified by an automated translation to UPPAAL, a model checker for timed automata. Once a complete model is built, designers can use the code generation functionality of the framework, which can generate Java code for the whole system.

Developed by the Critical Systems Research Group (ftsrg) at the Budapest University of Technology and Economics.

Package content:
- gamma.zip: the plugins constituting the Gamma Statechart Composition Framework.
- license.txt: the End User License Agreement (note that by using the tool, you accept the terms of the license agreement).
- gamma_tutorial.pdf: an extensive tutorial and user guide presenting the features of the tool.
- hu.bme.mit.gamma.tutorial.start.zip: Eclipse project containing the initial state of the tutorial.
- hu.bme.mit.gamma.tutorial.finish.zip: Eclipse project containing the final state of the tutorial.
- hu.bme.mit.gamma.tutorial.extra.zip: Eclipse project containing the solutions of the advanced excercises.

Included libraries:
- UPPAAL Meta-Model (University of Paderborn, https://svn-serv.cs.upb.de/muml_verification/trunk/)

Recommended Eclipse version and bundle:
- Eclipse 2023-09, Eclipse IDE for Java and DSL Developers bundle

3rd-party Eclipse components (should be installed separately):
- Xtext (https://www.eclipse.org/Xtext/, included in Eclipse bundle)
- VIATRA (https://www.eclipse.org/viatra/)
- Yakindu Statechart Tools (https://www.itemis.com/en/yakindu/state-machine/)

3rd-party tools used by Gamma (should be installed separately):
- UPPAAL (Uppsala and Aalborg Universities, http://www.uppaal.org/)
- Theta (Budapest University of Technology and Economics, https://github.com/ftsrg/theta)
- SPIN (Bell Labs, https://spinroot.com/)
- nuXmv (FBK, https://nuxmv.fbk.eu/)
- xSAP (FBK, https://xsap.fbk.eu/)

Installation:
- Have an Eclipse instance with EMF and Xtext and Java 17.
- Install VIATRA 2.8.0 and the Yakindu Statechart Tools 3.5.13.
- Exit Eclipse and extract the Gamma zip file into the root folder of Eclipse (this will create the plugins directory in the dropins folder, containing the JAR file of the Gamma).
- When starting Eclipse for the first time, you might need to start it with the -clean flag.
- Check if the plugin installed successfully in Help > About Eclipse and by clicking Installation Details. On the Plug-ins tab, sort the entries by Plugin-in Id and look for entries starting with hu.bme.mit.gamma. 
- For formal verification, download and extract UPPAAL. In order to let Gamma find the UPPAAL executables, add the bin-Win32 or bin-Linux folder to the path environment variable (depending on the operating system being used).
- If you want to use Theta, Spin, nuXmv or xSAP as a verification back-end, check out the instructions in the README at https://github.com/ftsrg/gamma/.

In case of questions, check http://gamma.inf.mit.bme.hu or contact us by sending an e-mail to gamma@inf.mit.bme.hu.